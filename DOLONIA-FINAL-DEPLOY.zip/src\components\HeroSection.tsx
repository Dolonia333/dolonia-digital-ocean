import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { ArrowRight, Cloud, Shield, Zap, X } from 'lucide-react';
import doloniaLogo from '@/assets/dolonia-logo.png';
import BinaryRain from "@/components/BinaryRain";
interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  benefits: string[];
}

const FeatureCard: React.FC<FeatureCardProps> = ({ icon, title, description, benefits }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsExpanded(true);
  };

  const handleClose = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsExpanded(false);
  };

  return (
    <>
      <div 
        className="flex items-center justify-center space-x-3 bg-ocean-surface/30 backdrop-blur-sm rounded-lg p-4 border border-ocean-surface cursor-pointer hover:bg-ocean-surface/50 transition-all duration-300"
        onClick={handleClick}
      >
        {icon}
        <span className="text-cyan-soft font-medium">{title}</span>
      </div>

      {/* Expanded Modal */}
      <Dialog open={isExpanded} onOpenChange={setIsExpanded}>
        <DialogContent className="bg-ocean-surface/95 border-ocean-surface backdrop-blur-md z-[9999]">
          <DialogHeader>
            <div className="flex items-center space-x-3">
              {icon}
              <DialogTitle className="text-foreground">{title}</DialogTitle>
            </div>
            <DialogDescription className="text-cyan-soft">
              {description}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-2">
            <h4 className="font-semibold text-cyan-bright">Key Benefits:</h4>
            <ul className="space-y-1">
              {benefits.map((benefit, index) => (
                <li key={index} className="text-cyan-soft text-sm flex items-center">
                  <div className="w-1.5 h-1.5 bg-cyan-bright rounded-full mr-2" />
                  {benefit}
                </li>
              ))}
            </ul>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

const HeroSection: React.FC = () => {
  return (
    <section className="min-h-screen flex items-center justify-center relative overflow-hidden pt-20">
      {/* Binary Rain */}
      <div className="absolute inset-0">
        <BinaryRain isActive={true} />
      </div>
      {/* Background gradient overlay */}
      <div className="absolute inset-0 bg-gradient-ocean opacity-80" />
      
      {/* Content */}
      <div className="container mx-auto px-6 text-center relative z-10">
        <div className="max-w-4xl mx-auto">
          {/* Badge */}
          <div className="inline-flex items-center space-x-2 bg-ocean-surface/50 backdrop-blur-sm border border-cyan-bright/30 rounded-full px-4 py-2 mb-8">
            <Zap size={16} className="text-cyan-bright" />
            <span className="text-cyan-soft text-sm font-medium">Modern Websites · Automation · Secure Hosting</span>
          </div>

          {/* Logo */}
          <div className="flex justify-center mb-8">
            <div className="relative">
               <img 
                 src={doloniaLogo} 
                 alt="Dolonia Logo" 
                 className="w-48 h-48 md:w-72 md:h-72 lg:w-96 lg:h-96 transition-all duration-100"
               />
               {/* Dramatic glitch effect overlay - timer based */}
               <div className="absolute inset-0">
                 <img 
                   src={doloniaLogo} 
                   alt="" 
                   className="w-48 h-48 md:w-72 md:h-72 lg:w-96 lg:h-96 absolute inset-0 mix-blend-multiply glitch-red"
                   style={{ 
                     filter: 'hue-rotate(180deg) contrast(300%) saturate(200%)',
                     transform: 'translate(-8px, -2px) scale(1.05)'
                   }}
                 />
                 <img 
                   src={doloniaLogo} 
                   alt="" 
                   className="w-48 h-48 md:w-72 md:h-72 lg:w-96 lg:h-96 absolute inset-0 mix-blend-multiply glitch-cyan"
                   style={{ 
                     filter: 'hue-rotate(90deg) contrast(300%) saturate(200%)',
                     transform: 'translate(8px, 2px) scale(0.95)'
                   }}
                 />
                 <img 
                   src={doloniaLogo} 
                   alt="" 
                   className="w-48 h-48 md:w-72 md:h-72 lg:w-96 lg:h-96 absolute inset-0 mix-blend-multiply glitch-purple"
                   style={{ 
                     filter: 'hue-rotate(270deg) contrast(300%) saturate(200%)',
                     transform: 'translate(-4px, 6px) scale(1.02)'
                   }}
                 />
               </div>
            </div>
          </div>


          {/* Feature highlights */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto">
            <FeatureCard
              icon={<Cloud className="text-cyan-bright h-6 w-6" />}
              title="Websites That Work"
              description="Professional sites built for real businesses. Fast, secure, and designed to convert visitors into customers."
              benefits={["Modern responsive design", "SEO optimized", "$1,500-$3,000 builds"]}
            />
            <FeatureCard
              icon={<Zap className="text-cyan-bright h-6 w-6" />}
              title="Smart Automation"
              description="n8n + AI workflows that handle your repetitive tasks. Save hours every week on busy work."
              benefits={["Custom workflow setup", "AI-powered tools", "$25-$99/month hosting"]}
            />
            <FeatureCard
              icon={<Shield className="text-cyan-bright h-6 w-6" />}
              title="Secure Hosting"
              description="Your site hosted on enterprise-grade infrastructure. Fast, reliable, and backed up daily."
              benefits={["99.9% uptime guarantee", "Daily backups", "$100/month maintenance"]}
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;