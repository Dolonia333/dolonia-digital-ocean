# fix-line-endings.ps1 - Normalize line endings to Unix (LF only)
(Get-Content -Raw .\style.css) -replace "`r`n", "`n" -replace "`r", "`n" | Set-Content -NoNewline -Encoding utf8 .\style.css
Write-Host "Line endings normalized to Unix (LF) format"