<?php
// test-read.php - quick diagnostics (remove when done)
header('Content-Type: text/plain');

$theme_dir = __DIR__;
$style_path = $theme_dir . '/style.css';

echo "THEME DIR: $theme_dir\n\n";

if (file_exists($style_path)) {
    echo "style.css: EXISTS\n";
    echo "filesize: " . filesize($style_path) . " bytes\n";
    echo "first 64 bytes (raw):\n";
    echo substr(file_get_contents($style_path), 0, 64) . "\n\n";
    echo "fileperms: " . substr(sprintf('%o', fileperms($style_path)), -4) . "\n";
    echo "owner uid/gid: " . @fileowner($style_path) . "/" . @filegroup($style_path) . "\n";
} else {
    echo "style.css: MISSING (PHP can't see it)\n";
}
?>