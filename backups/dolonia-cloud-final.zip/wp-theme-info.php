<?php
// wp-theme-info.php
require_once dirname(__DIR__, 2) . '/wp-load.php';
header('Content-Type: text/plain');

$theme = wp_get_theme( 'dolonia-cloud' );
echo "Theme Name: " . $theme->get('Name') . "\n";
echo "Template: " . $theme->get_template() . "\n";
echo "Stylesheet: " . $theme->get_stylesheet() . "\n";
echo "Is valid: " . ($theme->exists() ? 'yes' : 'no') . "\n";
echo "Stylesheet files:\n";
print_r($theme->get_stylesheet_files());
?>